jQuery(document).ready(function ($) {
    let activeCard = null;
    let expandedContent = $('.team-card-expanded');

    function getRowPosition(card) {
        const containerWidth = card.parent().width();
        const cardWidth = card.outerWidth(true);
        const cardsPerRow = Math.floor(containerWidth / cardWidth);
        const cardIndex = card.index();
        const rowIndex = Math.floor(cardIndex / cardsPerRow);
        const lastCardInRow = (rowIndex + 1) * cardsPerRow - 1;

        return {
            rowIndex: rowIndex,
            lastCardInRow: lastCardInRow
        };
    }

    function positionExpandedContent(card) {
        const container = card.closest('.team-cards-container');
        const expandedPosition = container.data('expanded-position');
        const pos = getRowPosition(card);

        if (expandedPosition === 'dynamic') {
            // Find the last card in the current row
            const cards = container.find('.team-card');
            const targetCard = cards.eq(Math.min(pos.lastCardInRow, cards.length - 1));

            expandedContent.detach().insertAfter(targetCard);
        } else {
            // Position at bottom of container
            expandedContent.detach().appendTo(container);
        }
    }

    function closeExpandedCard() {
        if (activeCard) {
            activeCard.removeClass('active');
            expandedContent.removeClass('active');
            activeCard = null;
        }
    }

    // Handle card click
    $('.team-card').on('click', function (e) {
        const clickedCard = $(this);
        const description = clickedCard.find('.expanded-description').html();

        // If clicking the same card that's already open, close it
        if (activeCard && activeCard[0] === clickedCard[0]) {
            closeExpandedCard();
            return;
        }

        // Close currently open card if exists
        closeExpandedCard();

        // Update expanded content
        expandedContent.find('.expanded-description').html(description);

        // Position expanded content
        positionExpandedContent(clickedCard);

        // Open clicked card
        clickedCard.addClass('active');
        expandedContent.addClass('active');
        activeCard = clickedCard;

        // Scroll expanded content into view
        if (window.innerWidth <= 768) {
            expandedContent[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            expandedContent[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    });

    // Close expanded card when clicking close button
    $('.close-expanded').on('click', function (e) {
        e.stopPropagation();
        closeExpandedCard();
    });

    // Close expanded card when clicking outside
    $(document).on('click', function (e) {
        if (!$(e.target).closest('.team-card').length &&
            !$(e.target).closest('.team-card-expanded').length) {
            closeExpandedCard();
        }
    });

    // Handle escape key
    $(document).on('keyup', function (e) {
        if (e.key === 'Escape') {
            closeExpandedCard();
        }
    });

    // Update positioning on window resize
    let resizeTimer;
    $(window).on('resize', function () {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function () {
            if (activeCard) {
                positionExpandedContent(activeCard);
            }
        }, 250);
    });
});